export interface Game {
  id: string;
  title: string;
  description: string;
  category: GameCategory;
  thumbnail: string;
  path: string;
  favorite: boolean;
}

export type GameCategory = 'action' | 'puzzle' | 'arcade' | 'strategy';

export interface ProxyState {
  url: string;
  isLoading: boolean;
  error: string | null;
}