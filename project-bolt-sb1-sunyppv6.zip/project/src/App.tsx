import React, { useState } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import HomePage from './pages/HomePage';
import GamesPage from './pages/GamesPage';
import GamePage from './pages/GamePage';
import ProxyPage from './pages/ProxyPage';
import SnakeGame from './games/SnakeGame';
import TicTacToeGame from './games/TicTacToeGame';
import MemoryGame from './games/MemoryGame';
import NotFoundPage from './pages/NotFoundPage';
import { Game } from './types';

const App: React.FC = () => {
  const [games, setGames] = useState<Game[]>([
    {
      id: 'snake',
      title: 'Snake Game',
      description: 'Classic snake game where you eat food and grow longer without hitting yourself or the walls.',
      category: 'arcade',
      thumbnail: 'https://images.pexels.com/photos/956999/milky-way-starry-sky-night-sky-star-956999.jpeg?auto=compress&cs=tinysrgb&w=800',
      path: '/games/snake',
      favorite: false
    },
    {
      id: 'tic-tac-toe',
      title: 'Tic Tac Toe',
      description: 'Classic game of X and O. Get three in a row to win!',
      category: 'strategy',
      thumbnail: 'https://images.pexels.com/photos/3964561/pexels-photo-3964561.jpeg?auto=compress&cs=tinysrgb&w=800',
      path: '/games/tic-tac-toe',
      favorite: false
    },
    {
      id: 'memory',
      title: 'Memory Match',
      description: 'Test your memory by matching pairs of cards. Find all pairs to win!',
      category: 'puzzle',
      thumbnail: 'https://images.pexels.com/photos/18111088/pexels-photo-18111088/free-photo-of-colorful-game-blocks-on-blue-background.jpeg?auto=compress&cs=tinysrgb&w=800',
      path: '/games/memory',
      favorite: false
    }
  ]);

  const toggleFavorite = (gameId: string) => {
    setGames(prevGames => 
      prevGames.map(game => 
        game.id === gameId ? { ...game, favorite: !game.favorite } : game
      )
    );
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-900 text-white">
      <Header />
      <main className="flex-grow container mx-auto px-4 py-8">
        <Routes>
          <Route path="/" element={<HomePage games={games} toggleFavorite={toggleFavorite} />} />
          <Route path="/games" element={<GamesPage games={games} toggleFavorite={toggleFavorite} />} />
          <Route path="/games/snake" element={<GamePage game={games[0]} component={<SnakeGame />} />} />
          <Route path="/games/tic-tac-toe" element={<GamePage game={games[1]} component={<TicTacToeGame />} />} />
          <Route path="/games/memory" element={<GamePage game={games[2]} component={<MemoryGame />} />} />
          <Route path="/proxy" element={<ProxyPage />} />
          <Route path="/404" element={<NotFoundPage />} />
          <Route path="*" element={<Navigate to="/404" replace />} />
        </Routes>
      </main>
      <Footer />
    </div>
  );
};

export default App;