import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { GameController, Globe, Menu, X, Search } from 'lucide-react';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsMenuOpen(false);
  }, [location]);

  return (
    <header 
      className={`sticky top-0 z-50 transition-all duration-300 ${
        isScrolled 
          ? 'bg-gray-900 shadow-lg' 
          : 'bg-gradient-to-r from-purple-900/80 to-pink-900/80 backdrop-blur-sm'
      }`}
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Link 
            to="/" 
            className="flex items-center space-x-2"
            aria-label="Crazy Games Home"
          >
            <GameController className="w-8 h-8 text-purple-400" />
            <span className="text-xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
              CrazyGames
            </span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link 
              to="/games" 
              className={`text-sm font-medium transition-colors hover:text-purple-400 ${
                location.pathname.includes('/games') ? 'text-purple-400' : 'text-gray-300'
              }`}
            >
              Games
            </Link>
            <Link 
              to="/proxy" 
              className={`text-sm font-medium transition-colors hover:text-purple-400 ${
                location.pathname === '/proxy' ? 'text-purple-400' : 'text-gray-300'
              }`}
            >
              <div className="flex items-center space-x-1">
                <Globe className="w-4 h-4" />
                <span>Proxy</span>
              </div>
            </Link>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search games..."
                className="w-64 py-2 pl-10 pr-4 rounded-full bg-gray-800 text-sm text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>
          </nav>

          {/* Mobile menu button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden rounded-md p-2 text-gray-300 hover:bg-gray-800"
            aria-label={isMenuOpen ? "Close menu" : "Open menu"}
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation */}
      {isMenuOpen && (
        <div className="md:hidden bg-gray-800 shadow-xl animate-fadeIn">
          <div className="container mx-auto px-4 py-3 space-y-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search games..."
                className="w-full py-2 pl-10 pr-4 rounded-full bg-gray-700 text-sm text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>
            <nav className="flex flex-col space-y-3">
              <Link 
                to="/games" 
                className={`p-2 rounded-md ${
                  location.pathname.includes('/games') 
                    ? 'bg-purple-900/50 text-purple-400' 
                    : 'text-gray-300 hover:bg-gray-700'
                }`}
              >
                Games
              </Link>
              <Link 
                to="/proxy" 
                className={`p-2 rounded-md flex items-center space-x-2 ${
                  location.pathname === '/proxy' 
                    ? 'bg-purple-900/50 text-purple-400' 
                    : 'text-gray-300 hover:bg-gray-700'
                }`}
              >
                <Globe className="w-4 h-4" />
                <span>Proxy</span>
              </Link>
            </nav>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;