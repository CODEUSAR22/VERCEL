import React from 'react';
import { Link } from 'react-router-dom';
import { Star, Tags } from 'lucide-react';
import { Game } from '../types';

interface GameCardProps {
  game: Game;
  toggleFavorite: (gameId: string) => void;
}

const GameCard: React.FC<GameCardProps> = ({ game, toggleFavorite }) => {
  const categoryColors = {
    action: 'bg-red-500',
    puzzle: 'bg-blue-500',
    arcade: 'bg-green-500',
    strategy: 'bg-yellow-500'
  };

  return (
    <div className="group bg-gray-800 rounded-lg overflow-hidden shadow-lg transition-all duration-300 hover:shadow-purple-500/20 hover:scale-[1.02]">
      <div className="relative">
        <Link to={game.path}>
          <img 
            src={game.thumbnail} 
            alt={game.title} 
            className="w-full h-48 object-cover transition-transform duration-500 group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-gray-900 to-transparent opacity-60 group-hover:opacity-40 transition-opacity"></div>
        </Link>
        <button 
          onClick={(e) => {
            e.preventDefault();
            toggleFavorite(game.id);
          }}
          className="absolute top-3 right-3 bg-gray-900/70 p-2 rounded-full hover:bg-gray-800 transition-colors"
          aria-label={game.favorite ? "Remove from favorites" : "Add to favorites"}
        >
          <Star 
            className={`w-5 h-5 ${game.favorite ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} 
          />
        </button>
        <div className="absolute bottom-3 left-3">
          <div className={`flex items-center space-x-1.5 ${categoryColors[game.category]} px-2 py-1 rounded-full text-xs font-medium`}>
            <Tags className="w-3 h-3" />
            <span className="capitalize">{game.category}</span>
          </div>
        </div>
      </div>
      <div className="p-4">
        <Link to={game.path}>
          <h3 className="text-lg font-semibold mb-2 group-hover:text-purple-400 transition-colors">
            {game.title}
          </h3>
        </Link>
        <p className="text-gray-400 text-sm line-clamp-2">{game.description}</p>
        <div className="mt-4">
          <Link 
            to={game.path}
            className="block w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white text-center py-2 rounded-md hover:from-purple-500 hover:to-pink-500 transition-colors"
          >
            Play Now
          </Link>
        </div>
      </div>
    </div>
  );
};

export default GameCard;