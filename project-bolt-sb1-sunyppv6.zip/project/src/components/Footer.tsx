import React from 'react';
import { Link } from 'react-router-dom';
import { GameController, Github, Twitter, Instagram } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-900 border-t border-gray-800">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="space-y-4">
            <Link to="/" className="flex items-center space-x-2">
              <GameController className="w-6 h-6 text-purple-400" />
              <span className="text-lg font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                CrazyGames
              </span>
            </Link>
            <p className="text-gray-400 text-sm">
              Play the best online games for free. No downloads, just fun!
            </p>
            <div className="flex space-x-4 pt-2">
              <a href="#" className="text-gray-400 hover:text-white transition-colors" aria-label="Github">
                <Github className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors" aria-label="Twitter">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors" aria-label="Instagram">
                <Instagram className="w-5 h-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-white font-medium mb-4">Games</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link to="/games" className="text-gray-400 hover:text-purple-400 transition-colors">
                  All Games
                </Link>
              </li>
              <li>
                <Link to="/games?category=arcade" className="text-gray-400 hover:text-purple-400 transition-colors">
                  Arcade
                </Link>
              </li>
              <li>
                <Link to="/games?category=puzzle" className="text-gray-400 hover:text-purple-400 transition-colors">
                  Puzzle
                </Link>
              </li>
              <li>
                <Link to="/games?category=strategy" className="text-gray-400 hover:text-purple-400 transition-colors">
                  Strategy
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-white font-medium mb-4">Useful Links</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link to="/proxy" className="text-gray-400 hover:text-purple-400 transition-colors">
                  Web Proxy
                </Link>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-purple-400 transition-colors">
                  About Us
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-purple-400 transition-colors">
                  Contact
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-purple-400 transition-colors">
                  Privacy Policy
                </a>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-white font-medium mb-4">Newsletter</h3>
            <p className="text-gray-400 text-sm mb-4">
              Subscribe to our newsletter for updates on new games and features.
            </p>
            <div className="flex">
              <input
                type="email"
                placeholder="Your email"
                className="flex-grow px-4 py-2 bg-gray-800 rounded-l-md focus:outline-none focus:ring-1 focus:ring-purple-500 text-sm"
              />
              <button className="bg-purple-600 text-white px-4 py-2 rounded-r-md hover:bg-purple-700 transition-colors text-sm">
                Subscribe
              </button>
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400 text-sm">
          <p>© {new Date().getFullYear()} CrazyGames. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;