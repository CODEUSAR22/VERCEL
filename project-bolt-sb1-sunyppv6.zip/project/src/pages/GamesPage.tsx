import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Filter, Search, Star } from 'lucide-react';
import GameCard from '../components/GameCard';
import { Game, GameCategory } from '../types';

interface GamesPageProps {
  games: Game[];
  toggleFavorite: (gameId: string) => void;
}

const GamesPage: React.FC<GamesPageProps> = ({ games, toggleFavorite }) => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<GameCategory | ''>('');
  const [showFavorites, setShowFavorites] = useState(false);
  const [filteredGames, setFilteredGames] = useState<Game[]>(games);
  const [isFilterOpen, setIsFilterOpen] = useState(false);

  useEffect(() => {
    const category = searchParams.get('category') as GameCategory | null;
    if (category) {
      setSelectedCategory(category);
    }
  }, [searchParams]);

  useEffect(() => {
    let result = games;
    
    if (searchTerm) {
      result = result.filter(game => 
        game.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        game.description.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    if (selectedCategory) {
      result = result.filter(game => game.category === selectedCategory);
    }
    
    if (showFavorites) {
      result = result.filter(game => game.favorite);
    }
    
    setFilteredGames(result);
  }, [games, searchTerm, selectedCategory, showFavorites]);

  const handleCategoryChange = (category: GameCategory | '') => {
    setSelectedCategory(category);
    if (category) {
      searchParams.set('category', category);
    } else {
      searchParams.delete('category');
    }
    setSearchParams(searchParams);
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <h1 className="text-3xl font-bold">Browse Games</h1>
        
        <div className="relative w-full md:w-64">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
          <input
            type="text"
            placeholder="Search games..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-gray-800 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 text-white"
          />
        </div>
      </div>
      
      <div className="flex flex-col sm:flex-row gap-4">
        {/* Mobile filter toggle */}
        <button
          onClick={() => setIsFilterOpen(!isFilterOpen)}
          className="sm:hidden flex items-center justify-center space-x-2 bg-gray-800 text-white py-2 px-4 rounded-lg"
        >
          <Filter className="h-5 w-5" />
          <span>Filters</span>
        </button>
        
        {/* Filters */}
        <div className={`${isFilterOpen ? 'block' : 'hidden'} sm:block sm:w-64 bg-gray-800 rounded-lg p-4 space-y-6`}>
          <div>
            <h3 className="text-lg font-medium mb-3">Categories</h3>
            <div className="space-y-2">
              <label className="flex items-center">
                <input
                  type="radio"
                  name="category"
                  checked={selectedCategory === ''}
                  onChange={() => handleCategoryChange('')}
                  className="form-radio text-purple-600"
                />
                <span className="ml-2 text-gray-300">All</span>
              </label>
              <label className="flex items-center">
                <input
                  type="radio"
                  name="category"
                  checked={selectedCategory === 'action'}
                  onChange={() => handleCategoryChange('action')}
                  className="form-radio text-purple-600"
                />
                <span className="ml-2 text-gray-300">Action</span>
              </label>
              <label className="flex items-center">
                <input
                  type="radio"
                  name="category"
                  checked={selectedCategory === 'puzzle'}
                  onChange={() => handleCategoryChange('puzzle')}
                  className="form-radio text-purple-600"
                />
                <span className="ml-2 text-gray-300">Puzzle</span>
              </label>
              <label className="flex items-center">
                <input
                  type="radio"
                  name="category"
                  checked={selectedCategory === 'arcade'}
                  onChange={() => handleCategoryChange('arcade')}
                  className="form-radio text-purple-600"
                />
                <span className="ml-2 text-gray-300">Arcade</span>
              </label>
              <label className="flex items-center">
                <input
                  type="radio"
                  name="category"
                  checked={selectedCategory === 'strategy'}
                  onChange={() => handleCategoryChange('strategy')}
                  className="form-radio text-purple-600"
                />
                <span className="ml-2 text-gray-300">Strategy</span>
              </label>
            </div>
          </div>
          
          <div className="border-t border-gray-700 pt-4">
            <label className="flex items-center">
              <input
                type="checkbox"
                checked={showFavorites}
                onChange={() => setShowFavorites(!showFavorites)}
                className="form-checkbox text-purple-600"
              />
              <span className="ml-2 text-gray-300 flex items-center">
                <Star className="h-4 w-4 text-yellow-400 mr-1" /> 
                Favorites Only
              </span>
            </label>
          </div>
          
          <div className="border-t border-gray-700 pt-4">
            <button
              onClick={() => {
                setSearchTerm('');
                setSelectedCategory('');
                setShowFavorites(false);
                setSearchParams({});
              }}
              className="w-full bg-gray-700 text-white py-2 rounded-lg hover:bg-gray-600 transition-colors"
            >
              Reset Filters
            </button>
          </div>
        </div>
        
        {/* Games Grid */}
        <div className="flex-1">
          {filteredGames.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredGames.map(game => (
                <GameCard
                  key={game.id}
                  game={game}
                  toggleFavorite={toggleFavorite}
                />
              ))}
            </div>
          ) : (
            <div className="bg-gray-800 rounded-lg p-8 text-center">
              <h3 className="text-xl font-medium mb-2">No games found</h3>
              <p className="text-gray-400">
                Try adjusting your filters or search query.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default GamesPage;