import React from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight, Gamepad2, Globe, Star } from 'lucide-react';
import GameCard from '../components/GameCard';
import { Game } from '../types';

interface HomePageProps {
  games: Game[];
  toggleFavorite: (gameId: string) => void;
}

const HomePage: React.FC<HomePageProps> = ({ games, toggleFavorite }) => {
  const featuredGames = games.slice(0, 3);
  
  return (
    <div className="space-y-12">
      {/* Hero Section */}
      <section className="relative rounded-2xl overflow-hidden">
        <div className="absolute inset-0">
          <img 
            src="https://images.pexels.com/photos/3165335/pexels-photo-3165335.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
            alt="Gaming background" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-gray-900 via-gray-900/90 to-transparent"></div>
        </div>
        
        <div className="relative py-16 px-6 md:py-24 md:px-12 max-w-4xl">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 text-white">
            Dive into <span className="bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">Crazy Games</span>
          </h1>
          <p className="text-lg text-gray-300 mb-8 max-w-2xl">
            Explore our collection of browser-based games and our web proxy feature. 
            No downloads required – just instant, free entertainment!
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Link 
              to="/games" 
              className="inline-flex items-center justify-center bg-gradient-to-r from-purple-600 to-pink-600 text-white font-medium py-3 px-6 rounded-lg hover:from-purple-500 hover:to-pink-500 transition-colors shadow-lg"
            >
              <Gamepad2 className="mr-2 h-5 w-5" />
              Play Games
            </Link>
            <Link 
              to="/proxy" 
              className="inline-flex items-center justify-center bg-gray-800 text-white font-medium py-3 px-6 rounded-lg hover:bg-gray-700 transition-colors"
            >
              <Globe className="mr-2 h-5 w-5" />
              Try Web Proxy
            </Link>
          </div>
        </div>
      </section>

      {/* Featured Games */}
      <section>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-white">Featured Games</h2>
          <Link 
            to="/games" 
            className="text-sm text-purple-400 hover:text-purple-300 transition-colors flex items-center"
          >
            View All <ChevronRight className="ml-1 h-4 w-4" />
          </Link>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {featuredGames.map(game => (
            <GameCard 
              key={game.id} 
              game={game} 
              toggleFavorite={toggleFavorite} 
            />
          ))}
        </div>
      </section>
      
      {/* Features Section */}
      <section className="bg-gray-800 rounded-xl p-6 md:p-8">
        <h2 className="text-2xl font-bold text-white mb-8 text-center">Why Choose CrazyGames?</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="flex flex-col items-center text-center p-4 rounded-lg bg-gray-750 border border-gray-700">
            <Gamepad2 className="h-12 w-12 text-purple-400 mb-4" />
            <h3 className="text-lg font-semibold mb-2">Endless Fun</h3>
            <p className="text-gray-400">Access a variety of games across multiple categories - all playable directly in your browser.</p>
          </div>
          
          <div className="flex flex-col items-center text-center p-4 rounded-lg bg-gray-750 border border-gray-700">
            <Globe className="h-12 w-12 text-pink-400 mb-4" />
            <h3 className="text-lg font-semibold mb-2">Web Proxy</h3>
            <p className="text-gray-400">Explore the web through our proxy feature, providing access to content with additional privacy.</p>
          </div>
          
          <div className="flex flex-col items-center text-center p-4 rounded-lg bg-gray-750 border border-gray-700">
            <Star className="h-12 w-12 text-teal-400 mb-4" />
            <h3 className="text-lg font-semibold mb-2">Free Forever</h3>
            <p className="text-gray-400">All our games and features are completely free to use - no subscriptions or hidden fees.</p>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="text-center py-8">
        <h2 className="text-2xl font-bold mb-4">Ready to start playing?</h2>
        <p className="text-gray-400 mb-6 max-w-2xl mx-auto">
          Jump into our collection of games right now or try our web proxy feature.
        </p>
        <div className="flex flex-col sm:flex-row justify-center gap-4">
          <Link 
            to="/games" 
            className="bg-gradient-to-r from-purple-600 to-pink-600 text-white font-medium py-3 px-8 rounded-lg hover:from-purple-500 hover:to-pink-500 transition-colors"
          >
            Browse Games
          </Link>
          <Link 
            to="/proxy" 
            className="bg-gray-800 text-white font-medium py-3 px-8 rounded-lg hover:bg-gray-700 transition-colors"
          >
            Try Proxy
          </Link>
        </div>
      </section>
    </div>
  );
};

export default HomePage;